/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author LG
 */
public class funcionarios {
  
    private String id;
    private String nome;
    private String email;
    private String telefone;
    private String cpf;
    private String rg;
    private String datadenasc;
    private String estadocivil;
    private String genero;
    private String nacionalidade;
    private String estado;
    private String cidade; 
    private String bairro;
    private String complemento;
    private String cep;
    
}
