package dao;

import java.util.ArrayList;

/**
 * Classe que define os métodos que serão obrigatórios nas classes DAO.
 * @author João Marcos
 */
public interface DAOGenerica<ObjetoGenerico> {
    
    /**
     * Método que deverá implementar o código para inserir dados em um tabela
     * O parâmetro deverá ser um objeto da classe específica onde será implementado esta interface.
     * Exemplo: na classe EscolaDao todas interações com o banco são referentes a tabela ESCOLA, então
     * o objeto passado como parâmetro será uma Escola
     * @param objt 
     */
    public void inserir(ObjetoGenerico objt);
    
    public void alterar(ObjetoGenerico objt);
    
    public void excluir();
    
    public ArrayList<ObjetoGenerico> consultar();
    
}
