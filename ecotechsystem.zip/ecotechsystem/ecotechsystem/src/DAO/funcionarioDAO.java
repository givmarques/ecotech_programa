/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
import connection.ConnectionFactory;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author LG
 */
public class funcionarioDAO {
    
    public void create(funcionario f) {
        
      Connection con = (Connection) ConnectionFactory.getConnection();
      PreparedStatement stmt = null;
      
        try {
            stmt = (PreparedStatement) con.prepareStatement("INSERT INTO funcionarios (id, nome, email, telefone, cpf, rg, datadenasc, estadocivil, genero, nacionalidade, estado, cidade, bairro, complemento, cep)VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
            stmt.setString(1,c.getId());
            stmt.setString(2,c.getNome());
            stmt.setString(3,c.getEmail());
            stmt.setString(4,c.getTelefone());
            stmt.setString(5,c.getCpf());
            stmt.setString(6,c.getRg());
            stmt.setString(7,c.getDatadenasc());
            stmt.setString(8,c.getEstadocivil());
            stmt.setString(9,c.getGenero());
            stmt.setInt(10,c.getNacionalidade());
            stmt.setString(11,c.getEstado());
            stmt.setString(12,c.getCidade());
            stmt.setString(13,c.getBairro());
            stmt.setString(14,c.getComplemento());
            stmt.setString(15,c.getCep());
            
            stmt.executeUpdate();
            
                    
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao salvar"+ex);
        }finally{
            ConnectionFactory.closeConnection(con,stmt);
            
        }
    }
}
