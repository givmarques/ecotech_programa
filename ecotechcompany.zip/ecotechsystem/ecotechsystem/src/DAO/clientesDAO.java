/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
import connection.ConnectionFactory;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import modelo.clientes;

/**
 *
 * @author LG
 */
public class clientesDAO {
    
    public void create(clientes c) {
        
      Connection con = (Connection) ConnectionFactory.getConnection();
      PreparedStatement stmt = null;
      
        try {
            stmt = (PreparedStatement) con.prepareStatement("INSERT INTO clientes (id, nome, email, telefone, estado, cidade, bairro, complemento, cep)VALUES(?,?,?,?,?,?,?,?,?)");
            stmt.setString(1,c.getId());
            stmt.setString(2,c.getNome());
            stmt.setString(3,c.getEmail());
            stmt.setInt(4,c.getTelefone());
            stmt.setString(5,c.getEstado());
            stmt.setString(6,c.getCidade());
            stmt.setString(7,c.getBairro());
            stmt.setString(8,c.getComplemento());
            stmt.setString(9,c.getCep());
            
            stmt.executeUpdate();
            
                    
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao salvar"+ex);
        }finally{
            ConnectionFactory.closeConnection(con,stmt);
            
        }
    }
}
